import React from 'react';

function Nav() {
  return (
    <div className='nav'>
      <span>PROPERTY</span>
      <span>MOVE IN DATE</span>
      <span>RENT</span>
      <span>DEPOSIT</span>
      <span>STATUS</span>
      <span> </span>
    </div>
  )
}

export default Nav;